import java.util.Date;

public class UserStatistics {
    private String username;
    private int messageCount;
    private Date firstMessageTime;
    private Date lastMessageTime;
    private double averageMessageLength;
    private String lastMessageText;

    public UserStatistics() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getMessageCount() {
        return messageCount;
    }

    public void setMessageCount(int messageCount) {
        this.messageCount = messageCount;
    }

    public Date getFirstMessageTime() {
        return firstMessageTime;
    }

    public void setFirstMessageTime(Date firstMessageTime) {
        this.firstMessageTime = firstMessageTime;
    }

    public Date getLastMessageTime() {
        return lastMessageTime;
    }

    public void setLastMessageTime(Date lastMessageTime) {
        this.lastMessageTime = lastMessageTime;
    }

    public double getAverageMessageLength() {
        return averageMessageLength;
    }

    public void setAverageMessageLength(double averageMessageLength) {
        this.averageMessageLength = averageMessageLength;
    }

    public String getLastMessageText() {
        return lastMessageText;
    }

    public void setLastMessageText(String lastMessageText) {
        this.lastMessageText = lastMessageText;
    }
}
