package com.example.ChatUzduotis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UzduotisChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(UzduotisChatApplication.class, args);
	}

}
