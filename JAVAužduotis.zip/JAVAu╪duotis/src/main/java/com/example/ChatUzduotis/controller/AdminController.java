import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MessageRepository messageRepository;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
        Optional<User> existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            throw new RuntimeException("User already exists");
        }
        // Set role to "user" by default
        user.setRole("user");
        return userRepository.save(user);
    }

    @DeleteMapping("/remove/{userId}")
    public void removeUser(@PathVariable Long userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            List<Message> userMessages = messageRepository.findByUserOrderByTimestampDesc(user);

            userRepository.delete(user);

            for (Message message : userMessages) {
                message.setUser(null); 
                messageRepository.save(message);
            }
        } else {
            throw new RuntimeException("User not found");
        }
    }

    @GetMapping("/statistics/{userId}")
    public UserStatistics getUserStatistics(@PathVariable Long userId) {
    }
}
