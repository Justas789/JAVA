import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MessageRepository messageRepository;

    @GetMapping("/user")
    public List<Message> getUserMessages(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
        return messageRepository.findByUserOrderByTimestampDesc(user);
    }

    @PostMapping("/user")
    public Message createUserMessage(@AuthenticationPrincipal UserDetails userDetails, @RequestBody Message message) {
        User user = userRepository.findByUsername(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));
        message.setUser(user);
        message.setTimestamp(new Date());
        return messageRepository.save(message);
    }
}
