import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import java.util.Arrays;
import java.util.Date;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class UserControllerTests {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserRepository userRepository;

    @Mock
    private MessageRepository messageRepository;

    private MockMvc mockMvc;

    public void setup() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    @Test
    public void testGetUserMessages() throws Exception {
        UserDetails userDetails = new User("testuser", "password", Arrays.asList());

        User user = new User("testuser", "user");

        Message message1 = new Message("Hello", new Date(), user);
        Message message2 = new Message("How are you?", new Date(), user);

        when(userRepository.findByUsername(userDetails.getUsername())).thenReturn(Optional.of(user));
        when(messageRepository.findByUserOrderByTimestampDesc(user)).thenReturn(Arrays.asList(message1, message2));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/messages/user"))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.size()").value(2))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].content").value("Hello"))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1].content").value("How are you?"));
    }

    @Test
    public void testCreateUserMessage() throws Exception {
        UserDetails userDetails = new User("testuser", "password", Arrays.asList());

        User user = new User("testuser", "user");

        Message newMessage = new Message("This is a new message", new Date(), user);

        when(userRepository.findByUsername(userDetails.getUsername())).thenReturn(Optional.of(user));
        when(messageRepository.save(Mockito.any(Message.class))).thenReturn(newMessage);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/messages/user")
                .content("{\"content\":\"This is a new message\"}")
                .contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content").value("This is a new message"));
    }
}
