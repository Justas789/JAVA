import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import java.util.Arrays;
import java.util.Date;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class AdminControllerTests {

    @InjectMocks
    private AdminController adminController;

    @Mock
    private UserRepository userRepository;

    @Mock
    private MessageRepository messageRepository;

    private MockMvc mockMvc;

    public void setup() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
    }

    @Test
    public void testRegisterUser() throws Exception {
        User newUser = new User("newuser", "user");

        when(userRepository.findByUsername(newUser.getUsername())).thenReturn(Optional.empty());
        when(userRepository.save(Mockito.any(User.class))).thenReturn(newUser);

        mockMvc.perform(MockMvcRequestBuilders.post("/api/admin/register")
                .content("{\"username\":\"newuser\",\"role\":\"user\"}")
                .contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.username").value("newuser"));
    }

    @Test
    public void testRemoveUser() throws Exception {
        // Mocking an existing user
        User existingUser = new User("existinguser", "user");

        // Mocking messages of the existing user
        Message message1 = new Message("Hello", new Date(), existingUser);
        Message message2 = new Message("How are you?", new Date(), existingUser);

        when(userRepository.findById(1L)).thenReturn(Optional.of(existingUser));
        when(messageRepository.findByUserOrderByTimestampDesc(existingUser)).thenReturn(Arrays.asList(message1, message2));

        mockMvc.perform(MockMvcRequestBuilders.delete("/api/admin/remove/1"))
                .andExpect(status().isOk());

    }
}
