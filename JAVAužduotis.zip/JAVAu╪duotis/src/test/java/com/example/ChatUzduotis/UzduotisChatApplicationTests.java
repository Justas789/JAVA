package com.example.ChatUzduotis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UzduotisChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
